package constant

const MESSAGE_NEW_USER = "New User"
const MESSAGE_CHAT = "Chat"
const MESSAGE_LEAVE = "Leave"

// directory file
const INDEX_PAGE = "template/chat.html"
